<?php
/**
 * Plugin Name: 年収診断（転職エージェント連携版）
 * Description: SWELL 環境向けの年収診断結果パーツ。ショートコード [salary_diagnosis_result] で結果カード＋おすすめエージェントを表示します。
 * Version: 0.1.0
 * Author: ミギナナメウエ
 */

if (!defined('ABSPATH')) {
    exit;
}

class Salary_Diagnosis_Plugin {
    const VERSION = '0.1.0';

    public static function init() {
        add_shortcode('salary_diagnosis_result', [__CLASS__, 'render_result']);
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
    }

    public static function enqueue_assets() {
        // 結果ページ用のスタイルを 1 ファイルにまとめる場合はここで登録・読み込み
        wp_register_style(
            'salary-diagnosis-result',
            plugins_url('assets/result.css', __FILE__),
            [],
            self::VERSION
        );
    }

    public static function render_result($atts = [], $content = '') {
        if (wp_script_is('salary-diagnosis-result', 'registered')) {
            wp_enqueue_style('salary-diagnosis-result');
        }

        ob_start();
        include __DIR__ . '/templates/result-page.php';
        return ob_get_clean();
    }
}

Salary_Diagnosis_Plugin::init();
